package edu.uga.cs4370.objects;

import java.util.ArrayList;
import java.util.List;

import edu.uga.cs4370.logic.Database;
import edu.uga.cs4370.logic.DatabaseInitialization;

public class Main {

	public static void main (String[] args){
	
		
		Database.initialize();
		
	}
	
}
