package edu.uga.cs4300.boundary;

import java.util.List;

import edu.uga.cs4300.objects.Product;
import edu.uga.cs4300.persistlayer.DatabaseProducts;

public class MainLogic {

	public MainLogic() {
		// TODO Auto-generated constructor stub
	}
/*
	public static void main(String[] args) {
List<Product> list = DatabaseProducts.getProducts();
		
	//Product pr = list.get(2);

		for(Product p: list)
			System.out.println(p.getName() + " " + p.getSRC());
		
		
		list = DatabaseProducts.getCart(1);
			System.out.println("-------User's cart-------");
			
		for(Product p: list)
			System.out.println(p.getName());
			
			DatabaseProducts.addItemToCart(pr, 1);
			System.out.println("Added " + pr.getName() + " to cart" );
			
			list = DatabaseProducts.getCart(1);
			System.out.println("-------User's new cart------");
			
		for(Product p: list)
			System.out.println(p.getName());
			
			
		}
		*/
	}


